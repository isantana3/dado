#include <bits/stdc++.h>
#include <ncurses.h>

using namespace std;
#define tam 3

int main()
{
    int t, j, i, k;  
    int pare, count = 0;
    float a[tam][tam], b[tam], x[tam], x0[tam], x2[tam], e, norma=0, soma=0,soma2=0;
    ofstream arquivo;

    arquivo.open("Resultado.txt");

    cin >> pare;

    // inserindo os elementos na matriz A 
     for(i=0; i<tam; i++)
     {
              for(j=0; j<tam; j++)
              {
                       scanf("%f",&a[i][j]);
              }
     }
     
     // inserindo os elementos da matriz dos termos independentes B
     //printf("Inserindo os termos independentes B:");
     for(i=0; i<tam; i++)
     {
              scanf("%f",&b[i]);
     }
     
    // inserindo os elementos do vetor x0 inicial
    //printf("Entrando com os valores do vetor x0 (inicial)\n");
    for(i=0; i<tam; i++)
    {
             scanf("%f",&x0[i]);
    }   

    //imprimindo a matriz
     arquivo << endl << "Matriz A:" << endl;
      for(i=0; i<tam; i++)
      {
             for (j=0;j<tam;j++)
             {
                 arquivo << a[i][j];
                 if(j==2)
                 {
                      arquivo << endl;
                 }
                 else
                 {
                      arquivo << "\t";
                 }
             }
    }  
    arquivo << endl << endl;

   //imprimindo a matriz de termos
    arquivo << endl << "Matriz B:" << endl;
    for (j=0;j<tam;j++)
    {
                 arquivo << b[j];
                 if(j==2)
                 {
                      arquivo << endl;
                 }
                 else
                 {
                      arquivo << "\t";
                 }
     }       
     arquivo << endl << endl;
    
    //imprimindo o vertor x
    arquivo << endl << "Matriz X:" << endl;
    for (j=0;j<tam;j++)
    {
                 arquivo << x0[j];
                 if(j==2)
                 {
                      arquivo << endl;
                 }
                 else
                 {
                      arquivo << "\t";
                 }
     }       
     arquivo << endl << endl;

    scanf("%f", &e);
    
    //Enquanto nao chegar ao limite de iteracoes maximo recebido como entrada
    while (count < pare)
    {
        
        for (i=0; i<tam; i++)
        {
            //calculando o valor do primeiro somatório.
            for (j=0; j<i; j++ )
            {
                soma=soma+a[i][j]*x0[j];
            }            
            //calculando o valor do somatório.
            for (j=i+1; j<tam; j++ )
            {            
                soma2 = soma2 + a[i][j]*x0[j]; 
            }
            x[i]=(b[i]-soma-soma2)/a[i][i];

            soma=0;
            soma2=0;

        }

        for (t=0; t<tam; t++)
        {
            x2[t] = x[t]-x0[t];
        }
        norma = (sqrt((x2[0]*x2[0])+(x2[1]*x2[1])+(x2[2]*x2[2]))) / sqrt((x[0]*x[0])+(x[1]*x[1])+(x[2]*x[2]));


        if (norma <= e)
        {            
            break;
        }
        else
        {
            for (t=0; t<tam; t++)
            {            
                x0[t] = x[t];
            }            
            k++;
        }
	count++;
    }
    for (i = 0; i < tam; i++){
    	arquivo << "x[" << i << "]=" << x[i] << endl;
    }
    
    arquivo.close();    

return 0;
}
