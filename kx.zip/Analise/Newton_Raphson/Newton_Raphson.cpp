#include <bits/stdc++.h>
#include <matheval.h>

using namespace std;

/* Tamanho do buffer de entrada.  */
#define BUFFER_SIZE 256

double newraph(double x0, double tol, int max, char* buffer);

int main (int argc, char **argv){
	double x0, xraiz, tol;	/* Variavel x valor.  */
	char buffer[BUFFER_SIZE];	/* Buffer de entrada.   */
        int length;			/* Comprimento do buffer acima. */
        void *f;		/* Avaliadores para função. */
        char **names;			/* Nomes de variáveis ​​de função. */
        int count;			/* Numero de variáveis ​​de função. */
        int i, max;			/* Loop contador. */
	ofstream arquivo;

	arquivo.open("Resultado.txt");

	fgets (buffer, BUFFER_SIZE, stdin);
	length = strlen (buffer);
	if (length > 0 && buffer[length - 1] == '\n')
	buffer[length - 1] = '\0';
	
	/* Crie o avaliador para a função.  */
	f = evaluator_create(buffer);
	assert (f);

	arquivo << "METODO NEWTON-RAPHSON." <<endl <<endl;

	cin >> x0;
	cin >> tol;
	cin >> max;

	// Chamada da funcao para calculo do metodo Newton-Raphson	
	xraiz = newraph(x0, tol, max, buffer);
    
	//Impressao na tela do valor da raiz aproximada
	arquivo << "Raiz aproximada = " << xraiz <<endl;


	/* Destrua os avaliadores.  */
        evaluator_destroy (f);


       exit (EXIT_SUCCESS);
	
}



//^
double newraph(double x0, double tol, int max, char* buffer){
    double xraiz, fderiv, iter[max];
    void *f, *fprim;
    int i;

   /* Crie o avaliador para a função.  */
	f = evaluator_create(buffer);
	assert (f);

    /* Criar avaliador para derivada da função.  */
       fprim = evaluator_derivative_x (f);

    fderiv = evaluator_evaluate_x (fprim, x0);

    // Condições iniciais, vetor de iteracoes e contador indice "i" do vetor
    iter[0] = x0;
    i = 0;

    // Iterações. Enquanto o valor funcional do valor da posicao i do vetor for maior que a tolerancia recebida como entrada
    while(evaluator_evaluate_x(f, iter[i]) > tol && i < max) {
    // Excedeu o nosso limite de iterações.
      if(i > max) {
         cout << "Não convergiu em"<< max << " iterações!!!\n";
         cout << "Provavelmente f'(x) está errada.\n";      
      }
      // Valor posterior do vetor recebe o valor atual do vetor menos o valor funcional no ponto atual 
      //dividido pela derivada da funcao aplicada ao ponto do slot atual do vetor
      iter[i+1] = iter[i] - (evaluator_evaluate_x(f, iter[i])) / (evaluator_evaluate_x(fprim ,iter[i]));
      i++;
   }

    /* Destrua os avaliadores.  */
     evaluator_destroy (f);
     evaluator_destroy (fprim);
    //raiz aproximada recebe o ultimo valor do vetor
    xraiz = iter[i];
    return xraiz;
}
