#include <bits/stdc++.h>
#include <matheval.h>

using namespace std;

/* Tamanho do buffer de entrada.  */
#define BUFFER_SIZE 256

double sec(double x0, double x1, double tol, int max, char* buffer);

int main (int argc, char **argv){
	double x0, x1, xraiz, tol;	/* Variavel x valor.  */
	char buffer[BUFFER_SIZE];	/* Buffer de entrada.   */
        int length;			/* Comprimento do buffer acima. */
        void *f;		/* Avaliadores para função. */
        char **names;			/* Nomes de variáveis ​​de função. */
        int count;			/* Numero de variáveis ​​de função. */
        int i, max;			/* Loop contador. */
	ofstream arquivo;

	arquivo.open("Resultado.txt");

	fgets (buffer, BUFFER_SIZE, stdin);
	length = strlen (buffer);
	if (length > 0 && buffer[length - 1] == '\n')
	buffer[length - 1] = '\0';
	
	/* Crie o avaliador para a função.  */
	f = evaluator_create(buffer);
	assert (f);
	
	//Valores de entrada
	arquivo << "METODO SECANTE." <<endl <<endl;
	
	cin >> x0;
	cin >> x1;
	cin >> tol;
	cin >> max;
	
	//Chamada da funcao para o calculo da raiz aproximada
	xraiz = sec(x0, x1, tol, max, buffer);
    
	//Impressao na tela do valor retornado pela funcao
	arquivo << "Raiz aproximada = " << xraiz <<endl;


	/* Destrua os avaliadores.  */
        evaluator_destroy (f);
	
	arquivo.close();

       exit (EXIT_SUCCESS);
	
}



//^
double sec(double x0, double x1, double tol, int max, char* buffer){
    double xraiz, f0, f1, x2;
    void *f;
    int i;

   /* Crie o avaliador para a função.  */
	f = evaluator_create(buffer);
	assert (f);

    // Condições iniciais.
    f0 = evaluator_evaluate_x(f, x0);
    
    //Loope de iteracoes 
    for(i = 1; i<= max; i++){
	//Calculo do valor funcional no ponto x1    	
	f1 = evaluator_evaluate_x(f, x1);
	//x2 recebe o valor calculado pela formula da secante	
	x2 = x1 - (x1 - x0) * (f1/(f1-f0));
	//se o comprimento do intervalo de valores atuais for menor que a tolerancia, retorna x2;	
	if (fabs(x2-x1) < tol)
		return x2;
	//manipulacao de valores de maneira analoga ao bubble sort (algoritmo de ordenacao)	
	x0 = x1;
	x1 = x2;
	f0 = f1;
    }
    //return x2;

    /* Destrua os avaliadores.  */
     evaluator_destroy (f);
     //evaluator_destroy (fprim);
    xraiz = x2;
    return xraiz;
}
