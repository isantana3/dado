#include <bits/stdc++.h>

using namespace std;

int main(){
	int i, j, k, n;
	ofstream arquivo;
	float A[20][20], c, x[10], soma = 0.0;
	
	arquivo.open("Resultado.txt");

	cin >> n;

	//cout << "Escreva os elementos da matriz aumentada: " <<endl <<endl;
	for(i = 1; i <= n; i++){
		for(j = 1; j <= (n+1); j++){
			cin >> A[i][j];		
		}	
	}
	
	//Loop vai variar o numero de colunas ate a ordem do sistema
	for(j = 1; j <= n; j++){
		//loop vai variar o numero de linhas ate a ordem do sistema
		for(i = 1; i <= n; i++){
			if(i > j){//se o indice da linha for maior que o da coluna
				//c recebe a fracao que na primeira iteracao multiplica a primeira linha 				
				c= -(A[i][j] / A[j][j]);
				// k vai variar ate o numero de colunas da matriz ampliada				
				for(k = 1; k <= n+1; k++){
					//mudanca de valor de termo de indice "i"  linha e "k" coluna
					A[i][k] = c * A[j][k] + A[i][k];
				}
			}		
		}	
	}
	// 
	arquivo << "Matriz após alteração:" << endl << endl;
	for(i = 1; i <= n; i++){
		for(j = 1; j <= (n+1); j++){
			if (j!= n+1){
				arquivo << fixed << setprecision(2) << A[i][j] << "\t";
			}
			else //ultimo elemento
				arquivo << fixed << setprecision(2) << A[i][j] << endl;
		}
	}
	//Solucionando o Sistema isolando x, y e z
	x[n] = A[n][n+1] / A[n][n]; // para z
	for(i =  n-1; i >= 1; i--){
		soma = 0;
		//		
		for(j = i+1; j <= n; j++){
			//somatorio soma-se com o valor da linha "i" e coluna "j" e multiplaca pelo valor ja achado anteriormente. (para z na primeira iteracao)			
			soma = soma + A[i][j] * x[j];
		}
		//calculo de y na primeira iteracao, x posteriormente
		x[i] = (A[i][n+1] - soma)/ A[i][i];
	}

	arquivo << endl<< "Solucao: ";
	for(i = 1; i <= n; i++){
		arquivo << "\n" << "x[" <<i<<"]"<<" = "<< x[i] <<"\t"; //impressao das solucoes
	}	
	cout << endl;

	arquivo.close();
	return 0;	 
}
