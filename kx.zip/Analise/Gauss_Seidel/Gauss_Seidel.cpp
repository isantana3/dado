#include <bits/stdc++.h>

using namespace std;
#define X 2

int main()
{
    float x[X][X+1],a[X], ae, max,t,s,e;
    int i,j,r,mxit;
    ofstream arquivo;

    arquivo.open("Resultado.txt");

    for(i=0;i<X;i++) 
	a[i]=0;
    
    for(i=0;i<X;i++)
    {
    	for(j=0;j<X+1;j++)
    	{
    		scanf("%f",&x[i][j]);
    	}
    }
    
    //tol
    cin >> ae;
    //max iteracoes
    cin >> mxit;

    arquivo << "Iteracao\tx[1]\tx[2]\n";
    for(r=1;r<=mxit;r++)
    {
        max=0;
        for(i=0;i<X;i++)
        {
            s=0;
            for(j=0;j<X;j++)
            if(j!=i) 
		s+=x[i][j]*a[j];
            t=(x[i][X]-s)/x[i][i];
            e=fabs(a[i]-t);
            a[i]=t;
        }
        arquivo << "\t" << r << "\t";
        for(i=0;i<X;i++)
        arquivo << fixed << setprecision(3) << a[i] << "\t";
        arquivo << endl;
        if(max<ae)
        {
            arquivo << " Converge na " << r << "a" << " iteracao\n";
            for(i=0;i<X;i++)
            arquivo << "a[" << i+1 << "] = " << a[i] << endl;
             
            arquivo.close();
            return 0;
        }

        }
    arquivo.close();
    }
