#include <bits/stdc++.h>

using namespace std;

void lu(float a[][10], float l[][10], float u[][10], int n);
void output(float x[][10], int n, ofstream &arquivo);
 
int main(int argc, char **argv)
{
    float a[10][10], l[10][10], u[10][10];
    int n = 0, i = 0, j = 0;
    ofstream arquivo;

    arquivo.open("Resultado.txt");

    //Entrada do valor de ordem
    cin >> n;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            //Entrada de valores
            cin >> a[i][j];
        }
    }
    lu(a, l, u, n);
    arquivo << "\nDecomposicao L\n\n";
    //Impressao da decomposicao triangular inferior L
    output(l, n, arquivo);
    //Impressao da decomposicao triangular superior U
    arquivo << "\nDecomposicao U\n\n";
    output(u, n, arquivo);

    arquivo.close();
    return 0;
}

// funcao de implementacao do metodo e manipulacao da matriz
void lu(float a[][10], float l[][10], float u[][10], int n)
{
    int i = 0, j = 0, k = 0;// indices das matrizes

    //loop principal 1 (manipulacao por linhas)
    for (i = 0; i < n; i++)
    {
	//calculo da decomposicao L        
	for (j = 0; j < n; j++)
        {
            if (j < i) // semelhante ao metodo elim. gauss, porem diferente
                l[j][i] = 0;
            else
            {
                l[j][i] = a[j][i];
                for (k = 0; k < i; k++)
                {
                    l[j][i] = l[j][i] - l[j][k] * u[k][i];
                }
            }
        }
	//loope principal 2 (manipulacao por colunas inicialmente)
        for (j = 0; j < n; j++)
        { //calculo da decomposicao U
            if (j < i)
                u[i][j] = 0;
            else if (j == i)
                u[i][j] = 1;
            else
            {
                u[i][j] = a[i][j] / l[i][i];
                for (k = 0; k < i; k++)
                {
                    u[i][j] = u[i][j] - ((l[i][k] * u[k][j]) / l[i][i]);
                }
            }
        }
    }
}

//Funcao auxiliar de impressao das matrizes
void output(float x[][10], int n, ofstream &arquivo)
{
    int i = 0, j = 0;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            arquivo << x[i][j] << "\t";
        }
        arquivo << "\n";
    }
}
