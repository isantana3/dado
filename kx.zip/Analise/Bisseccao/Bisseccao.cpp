#include <bits/stdc++.h>
#include <matheval.h>

using namespace std;

/* Tamanho do buffer de entrada.  */
#define BUFFER_SIZE 256

double bissec (double a, double b, double tol, char* buffer);

int main (int argc, char **argv){
	double a, b, c, tol, fa,fb,fc;
	ofstream arquivo;	
	char buffer[BUFFER_SIZE];	/* Buffer de entrada.   */
        int length;			/* Comprimento do buffer acima. */
        void *f;		/* Avaliadores para função. */
        char **names;			/* Nomes de variáveis ​​de função. */
        int count;			/* Numero de variáveis ​​de função. */
        double x;			/* Variavel x valor.  */
        int i;			/* Loop contador. */
	
	arquivo.open("Resultado.txt");

	//printf ("f(x) = ");
	fgets (buffer, BUFFER_SIZE, stdin);
	length = strlen (buffer);
	if (length > 0 && buffer[length - 1] == '\n')
	buffer[length - 1] = '\0';
	
	/* Crie o avaliador para a função.  */
	f = evaluator_create(buffer);
	assert (f);	

	/*Recebo os valores de a, b e o Erro */	

	arquivo << "METODO DA BISSECCAO." <<endl <<endl;

	cin >> a;
	cin >> b;
	cin >> tol;

	
	//Calculando os valores funcionais de a e b.
        fa = evaluator_evaluate_x (f, a);
        fb = evaluator_evaluate_x (f, b);

	/* Verificacao do intervalo. */	
	if((fa) * (fb) > 0)
    	{
        	cout << "O intervalo nao eh aplicavel." << endl << endl;
    
	}
  	
	//funcao que calcula a raiz aproximada da funcao
	c = bissec (a, b, tol, buffer);
	
    	//Mostra a raiz na tela
	arquivo << "Raiz aproximada = " << c <<endl;

	arquivo.close();
	/* Destrua os avaliadores.  */
        evaluator_destroy (f);


       exit (EXIT_SUCCESS);
	
}



//Implementacao da funcao para implementacao do metodo da bisseccao
double bissec(double a, double b, double tol, char* buffer){
    double c,fa,fb,fc;
    void *f;

	//^


   /* Crie o avaliador para a função.  */
	f = evaluator_create(buffer);
	assert (f);
   
    //Calculando os valores funcionais de a e b.
    fa = evaluator_evaluate_x (f, a);
    fb = evaluator_evaluate_x (f, b);

    //Enquanto o |b-a| > tolerancia
    while(fabs(b-a) > tol)
    {
        //media do intervalo
        c = (a+b)/2;
	//calculando valor funcional da variavel c
        fc = evaluator_evaluate_x (f, c);
        //Se o valor funcional de a x c for menor que 0, b recebe o valor de c
	if(fa * fc < 0)
        {
            b = c;
            fb = fc;
        }
	//Senao, se o valor funcional de a x c for maior que 0, a recebe o valor de c
        else
        {
            a = c;
            fa = fc;
        }
    }
    
    c = (a+b)/2;
    /* Destrua os avaliadores.  */
     evaluator_destroy (f);
    return c;
}
