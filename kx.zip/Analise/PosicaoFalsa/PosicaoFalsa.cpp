#include <bits/stdc++.h>
#include <matheval.h>

using namespace std;

/* Tamanho do buffer de entrada.  */
#define BUFFER_SIZE 256

double posfal(double a, double b, double tol, char* buffer);

int main (int argc, char **argv){
	double a, b, c, tol, fa,fb,fc;	
	char buffer[BUFFER_SIZE];	/* Buffer de entrada.   */
        int length;			/* Comprimento do buffer acima. */
        void *f;		/* Avaliadores para função. */
        char **names;			/* Nomes de variáveis ​​de função. */
        int count;			/* Numero de variáveis ​​de função. */
        double x;			/* Variavel x valor.  */
        int i;			/* Loop contador. */
	ofstream arquivo;
	
	arquivo.open("Resultado.txt");

	fgets (buffer, BUFFER_SIZE, stdin);
	length = strlen (buffer);
	if (length > 0 && buffer[length - 1] == '\n')
	buffer[length - 1] = '\0';
	
	/* Crie o avaliador para a função.  */
	f = evaluator_create(buffer);
	assert (f);	

	/*Recebo os valores de a, b e o Erro */	

	arquivo << "METODO DA POSICAO FALSA." <<endl <<endl;

	cin >> a;
	cin >> b;
	cin >> tol;

	
	//Calculando os valores funcionais de a e b.
        fa = evaluator_evaluate_x (f, a);
        fb = evaluator_evaluate_x (f, b);

	/* Verificacao do intervalo. */	
	if((fa) * (fb) > 0)
    	{
        	arquivo << "O intervalo nao e aplicavel." << endl << endl;
        	arquivo << "Digite um novo intervalo." << endl << endl;

        	scanf("%lf",&a);
        	scanf("%lf",&b);
    
	}
  	
	c = posfal(a, b, tol, buffer);
	
    
	arquivo << "Raiz aproximada = " << c << endl;


	/* Destrua os avaliadores.  */
        evaluator_destroy (f);

	arquivo.close();

       exit (EXIT_SUCCESS);
	
}




double posfal(double a, double b, double tol, char* buffer){
    double c,fa,fb,fc;
    void *f;

	//^


   /* Crie o avaliador para a função.  */
	f = evaluator_create(buffer);
	assert (f);
   
    //Calculando os valores funcionais de a e b.
    fa = evaluator_evaluate_x (f, a);
    fb = evaluator_evaluate_x (f, b);

    //b*f(a)-f(b)*a/f(a)-f(b)
    c = (b*fa-fb*a)/(fa-fb);
    fc = evaluator_evaluate_x (f, c);
    
    //Enquanto |f(c)| > tolerancia	
    while (fabs(fc) > tol)
    {
        c = (b*fa-fb*a)/(fa-fb);
        //calculando novo f(c)
        fc = evaluator_evaluate_x (f, c);

	//Se a multiplicacao dos valores funcionais de a e c forem menores que 0, b recebe o valor de c.        
	if(fa*fc<0)
        {
            b=c;
            fb=fc;
        }
	//Senao, a recebe o valor de c.
        else
        {
            a=c;
            fa=fc;
        }
    }

    /* Destrua os avaliadores.  */
     evaluator_destroy (f);
    return c;
}
